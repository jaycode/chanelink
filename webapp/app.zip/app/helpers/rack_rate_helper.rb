module RackRateHelper
end
