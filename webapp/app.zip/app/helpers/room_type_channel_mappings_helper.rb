module RoomTypeChannelMappingsHelper

  # show master rate field if master rate type is selected
  def rate_configuration_radio_js
    javascript_tag "$(function() {
        $(\"input[name='room_type_channel_mapping[rate_configuration]']\").change(function(e){
          if($(this).val() == '#{Constant::RTCM_MASTER_RATE}') {
            $('.masterRate').show();
          } else {
            $('.masterRate').hide();
          }
      });
    });"
  end
  
end
