module RatesHelper
end
