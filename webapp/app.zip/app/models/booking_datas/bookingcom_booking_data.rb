# unused for now, because decide no to store booking.com data
class BookingcomBookingData < ActiveRecord::Base

  belongs_to :booking

end