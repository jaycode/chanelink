# represent member super role
class SuperRole < MemberRole

  CNAME = 'super'
  
  def cname
    CNAME
  end

end
