# represent member config role
class ConfigRole < MemberRole

  CNAME = 'config'

  def cname
    CNAME
  end

end
