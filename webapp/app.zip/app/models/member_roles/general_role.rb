# represent member general role
class GeneralRole < MemberRole

  CNAME = 'general'

  def cname
    CNAME
  end

end
