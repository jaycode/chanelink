# super class for all channel/OTA bookings
class Booking < ActiveRecord::Base

  extend Unscoped
  
  belongs_to :channel
  belongs_to :property
  belongs_to :room_type
  belongs_to :pool
  belongs_to :booking_status

  unscope :property, :room_type, :pool

  scope :date_start_between, lambda {|start_period, end_period| {:conditions => ["date_start >= ? and date_start <= ?", start_period, end_period]}}
  scope :booking_date_between, lambda {|start_period, end_period| {:conditions => ["booking_date >= ? and booking_date <= ?", start_period, end_period]}}
  scope :new_only, lambda { {:conditions => ["booking_status_id = ?", BookingStatus.new_type.id]} }

  after_create :generate_uuid

  # difference between booking date and stay date
  def lead_time
    (self.date_start.to_date - self.booking_date.to_date).to_i
  end

  # calculate length of stay in days
  def length_of_stay
    (self.date_end.to_date - self.date_start.to_date).to_i - 1
  end
  
  def channel_booking_id
    if self.channel == AgodaChannel.first
      self.agoda_booking_id
    elsif self.channel == ExpediaChannel.first
      self.expedia_booking_id
    elsif self.channel == BookingcomChannel.first
      self.bookingcom_booking_id
    end
  end

  def generate_uuid
    if self.uuid.blank?
      self.uuid = SecureRandom.hex(10)
      self.save
    end
  end
  
end