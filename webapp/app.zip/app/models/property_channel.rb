# represent a channel mapping to a property
class PropertyChannel < ActiveRecord::Base

  extend Unscoped

  belongs_to :property
  belongs_to :channel
  belongs_to :pool
  has_one :currency_conversion

  unscope :property, :pool

  validates :property, :presence => true
  validates :channel, :presence => true
  validates :pool, :presence => true

  validates :rate_conversion_multiplier, :allow_nil => true, :numericality => {:greater_than => 0.5, :less_than => 10000000000000}, :if => :is_validate_rate_conversion_multiplier?
  
  #validates :agoda_currency, :presence => true, :if => :is_validate_agoda_info?
  validates :agoda_username, :presence => true, :if => :is_validate_agoda_info?
  validates :agoda_password, :presence => true, :if => :is_validate_agoda_info?

  validates :expedia_reservation_email_address, :presence => true, :format => { :with => /^[^@][\w.-]+@[\w.-]+[.][a-z]{2,4}$/i}, :if => :is_validate_expedia_info?
  validates :expedia_modification_email_address, :presence => true, :format => { :with => /^[^@][\w.-]+@[\w.-]+[.][a-z]{2,4}$/i}, :if => :is_validate_expedia_info?
  validates :expedia_cancellation_email_address, :presence => true, :format => { :with => /^[^@][\w.-]+@[\w.-]+[.][a-z]{2,4}$/i}, :if => :is_validate_expedia_info?
  #validates :expedia_currency, :presence => true, :if => :is_validate_expedia_info?

  validates :bookingcom_username, :presence => true, :if => :is_validate_bookingcom_info?
  validates :bookingcom_password, :presence => true, :if => :is_validate_bookingcom_info?
  validates :bookingcom_reservation_email_address, :presence => true, :format => { :with => /^[^@][\w.-]+@[\w.-]+[.][a-z]{2,4}$/i}, :if => :is_validate_bookingcom_info?

  validates :tiketcom_hotel_key, :presence => true, :if => :is_validate_tiketcom_info?

  scope :not_approved, lambda { {:conditions => ["approved = ?", true]} }
  scope :active_only, lambda { {:conditions => ["disabled = ?", false]} }

  accepts_nested_attributes_for :currency_conversion

  attr_accessor :skip_channel_specific
  attr_accessor :skip_rate_conversion_multiplier
  attr_accessor :previous_pool_id

  def is_validate_agoda_info?
    return false if self.skip_channel_specific
    self.channel == AgodaChannel.first
  end

  def is_validate_expedia_info?
    return false if self.skip_channel_specific
    self.channel == ExpediaChannel.first
  end

  def is_validate_bookingcom_info?
    return false if self.skip_channel_specific
    self.channel == BookingcomChannel.first
  end

  def is_validate_tiketcom_info?
    return false if self.skip_channel_specific
    self.channel == TiketcomChannel.first
  end

  def is_validate_rate_conversion_multiplier?
    return false if self.skip_rate_conversion_multiplier
    true
  end

  # sync all channel data to OTA
  def sync_all_data
    return if self.disabled?
    self.channel.class.get_all_room_type_mapping(self.property).each do |rtcm|
      rtcm.delay.sync_all_data
    end
  end

  # change all record of this mapping to a new pool
  def migrate_room_data_to_new_pool
    return if self.previous_pool_id.blank?

    # find all the mapping
    self.channel.class.get_all_room_type_mapping(self.property).each do |rtcm|
      rtcm.migrate_data_to_new_pool(self.pool_id, self.previous_pool_id)
    end
    
  end

  # delete all master rate mapping
  def delete_all_master_rate_mapping
    RoomTypeMasterRateChannelMapping.pool_id(self.previous_pool_id).find_all_by_channel_id(self.channel.id).each do |rtcm|
      rtcm.update_attribute(:deleted, true)
    end
  end

  # check if this mapping enabled and approved
  def enabled_and_approved?
    if self.disabled == false and self.approved == true
      true
    else
      false
    end
  end
  
end
