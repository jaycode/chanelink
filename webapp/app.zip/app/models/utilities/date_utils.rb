# useful date utilities for User Interface
class DateUtils

  def self.date_to_key(date)
    date.strftime('%F')
  end

end
