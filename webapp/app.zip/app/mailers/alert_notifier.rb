# sending email for alert
class AlertNotifier < ActionMailer::Base
  
  default :from => "Chanelink <no-reply@chanelink.com>"

  def email_zero_inventory(alert)
    @alert = alert
    @property = alert.property
    receiver = alert.receiver
    @receiver = receiver.name

    mail :to => receiver.email, :subject => alert.to_display
  end

   def email_property_channel_approved(alert)
    @alert = alert
    @property = alert.property
    receiver = alert.receiver
    @receiver = receiver.name

    mail :to => receiver.email, :subject => alert.to_display
  end
  
end
