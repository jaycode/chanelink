# send email to chanelink team
class TeamNotifier < ActionMailer::Base
  
  default :from => "Chanelink <no-reply@chanelink.com>"

  def email_failed_xml_push(change_set_channel_log)
    @change_set_channel_log = change_set_channel_log
    @channel = change_set_channel_log.change_set_channel.channel
    @property = change_set_channel_log.change_set_channel.change_set.property

    mail :to => APP_CONFIG[:support_email], :subject => "Failed XML push for #{@property.name} #{@channel.name}"
  end
  
end
