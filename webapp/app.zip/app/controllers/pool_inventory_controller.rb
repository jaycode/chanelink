# not used at this moment
class PoolInventoryController < ApplicationController
 
end
